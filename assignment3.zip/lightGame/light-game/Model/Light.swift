
import Foundation

struct Light {
    
    var status = false
    
    var selected = false
}
